module Shifter (
	result,
	leftRight,
	shamt,
	sftSrc
);

	//I/O ports
	output [32-1:0] result;

	input leftRight;
	input [5-1:0] shamt;
	input [32-1:0] sftSrc;

	//Internal Signals
	reg [32-1:0] result;

	//Main function
	always @(*) begin
		if (leftRight)
			result= sftSrc << shamt;
		else
			result= sftSrc >> shamt;
	end

endmodule

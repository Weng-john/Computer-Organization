module ALU (
    input  [31:0] aluSrc1,
    input  [31:0] aluSrc2,
    input  [3:0]  ALU_operation_i,

    output [31:0] result,
    output zero,
    output overflow
);

    // Internal Signals
    wire [31:0] carry;
    wire carryOut;
    wire [31:0] sum;
    wire invertA = ALU_operation_i[3];
    wire invertB = ALU_operation_i[2];
    wire [1:0] operation = ALU_operation_i[1:0];

    // Internal nets for inverted inputs
    wire [31:0] aluSrc1_inv = invertA ? ~aluSrc1 : aluSrc1;
    wire [31:0] aluSrc2_inv = invertB ? ~aluSrc2 : aluSrc2;

    // Arithmetic operations
    assign {carryOut, sum} = aluSrc1_inv + aluSrc2_inv + invertB;

    // Logic operations
    wire [31:0] and_result = aluSrc1_inv & aluSrc2_inv;
    wire [31:0] or_result  = aluSrc1_inv | aluSrc2_inv;

    // Comparison operation (set on less than)
    wire slt_result = (aluSrc1[31] != aluSrc2[31]) ? aluSrc1[31] : sum[31];

    // Result selection
    assign result = (operation == 2'b00) ? and_result :
                    (operation == 2'b01) ? or_result  :
                    (operation == 2'b10) ? sum :
                    (operation == 2'b11) ? {31'b0, slt_result} : 32'b0;

    // Zero flag
    assign zero = (result == 32'b0);

    // Overflow detection for signed addition/subtraction
    assign overflow = (operation == 2'b10) && (((aluSrc1[31] == aluSrc2[31]) && (sum[31] != aluSrc1[31])));

endmodule


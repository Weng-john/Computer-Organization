`include "Program_Counter.v"
`include "Adder.v"
`include "Instr_Memory.v"
`include "Mux2to1.v"
`include "Mux3to1.v"
`include "Reg_File.v"
`include "Decoder.v"
`include "ALU_Ctrl.v"
`include "Sign_Extend.v"
`include "Zero_Filled.v"
`include "ALU.v"
`include "Shifter.v"
`include "Data_Memory.v"

module Simple_Single_CPU (
    clk_i,
    rst_n
);

	//I/O port
	input clk_i;
	input rst_n;

	//Internal Signles
	wire [32-1:0] pc_in;
	wire [32-1:0] pc_out;
	wire [32-1:0] adder1_res;
	wire [32-1:0] adder2_res;
	wire [32-1:0] signExtend_res;
	wire [32-1:0] instr;
	wire [32-1:0] RSdata;
	wire [32-1:0] RTdata;
	wire [32-1:0] DMdata;
	wire [32-1:0] zeroData;
	wire [32-1:0] shifter_res;
	
		// Mux output signal
		wire [32-1:0] PCSrc_o;
		wire [32-1:0] Jump_o;
		wire [32-1:0] WriteRF_data;
		wire [32-1:0] ALUSrc_o;
		wire [32-1:0] compute_res;
		wire [5-1:0] RegDst_o;
	
		// decoder signal
		wire jump_sig;
		wire [3-1:0] ALUOp_sig;
		wire ALUSrc_sig;
		wire Branch_sig;
		wire BranchType_sig;
		wire MemWrite_sig;
		wire MemRead_sig;
		wire MemtoReg_sig;
		wire RegWrite_sig;
		wire RegDst_sig;
		
		//ALU signal
		wire [32-1:0] ALU_res;
		wire ALUzero;
		wire ALUoverflow;
		
		//ALU control signal
		wire [4-1:0] ALUopcode;
		wire [2-1:0] FURslt_sig;
		wire leftRight_o;
		wire JRsrc_sig;

	//modules
	Program_Counter PC (
		.clk_i(clk_i),
		.rst_n(rst_n),
		.pc_in_i(pc_in),
		.pc_out_o(pc_out)
	);

	Adder Adder1 (
		.src1_i(pc_out),
		.src2_i(32'd4),
		.sum_o (adder1_res)
	);

	Adder Adder2 (
		.src1_i(adder1_res),
		.src2_i({signExtend_res[29:0], 2'b00}),
		.sum_o (adder2_res)
	);

	Mux2to1 #(
		.size(32)
	) Mux_branch (
		.data0_i (adder1_res),
		.data1_i (adder2_res),
		.select_i((Branch_sig & (~BranchType_sig ^ ALUzero))),
		.data_o  (PCSrc_o)
	);

	Mux2to1 #(
		.size(32)
	) Mux_jump (
		.data0_i(PCSrc_o),
		.data1_i({adder1_res[31:28], instr[25:0], 2'b00}),
		.select_i(Jump_sig),
		.data_o(Jump_o)
	);

	Mux2to1 #(
		.size(32)
	) Mux_jr (
		.data0_i(Jump_o),
		.data1_i(RSdata),
		.select_i(JRsrc_sig),
		.data_o(pc_in)
	);

	Instr_Memory IM (
		.pc_addr_i(pc_out),
		.instr_o  (instr)
	);

	Mux2to1 #(
		.size(5)
	) Mux_RS_RT (
		.data0_i (instr[20:16]),
		.data1_i (instr[15:11]),
		.select_i(RegDst_sig),
		.data_o  (RegDst_o)
	);

	Reg_File RF (
		.clk_i(clk_i),
		.rst_n(rst_n),
		.RSaddr_i(instr[25:21]),
		.RTaddr_i(instr[20:16]),
		.RDaddr_i(RegDst_o),
		.RDdata_i(WriteRF_data),
		.RegWrite_i(RegWrite_sig),
		.RSdata_o(RSdata),
		.RTdata_o(RTdata)
	);

	Decoder Decoder (
		.instr_op_i(instr[31:26]),
		.RegWrite_o(RegWrite_sig),
		.ALUOp_o(ALUOp_sig),
		.ALUSrc_o(ALUSrc_sig),
		.RegDst_o(RegDst_sig),
		.Jump_o(Jump_sig),
		.Branch_o(Branch_sig),
		.BranchType_o(BranchType_sig),
		.MemRead_o(MemRead_sig),
		.MemWrite_o(MemWrite_sig),
		.MemtoReg_o(MemtoReg_sig)
	);

	ALU_Ctrl AC (
		.funct_i(instr[5:0]),
		.ALUOp_i(ALUOp_sig),
		.ALU_operation_o(ALUopcode),
		.FURslt_o(FURslt_sig),
		.leftRight_o(leftRight_o),
		.JRsrc_o(JRsrc_sig)
	);

	Sign_Extend SE (
		.data_i(instr[15:0]),
		.data_o(signExtend_res)
	);

	Zero_Filled ZF (
		.data_i(instr[15:0]),
		.data_o(zeroData)
	);

	Mux2to1 #(
		.size(32)
	) ALU_src2Src (
		.data0_i (RTdata),
		.data1_i (signExtend_res),
		.select_i(ALUSrc_sig),
		.data_o  (ALUSrc_o)
	);

	ALU ALU (
		.aluSrc1(RSdata),
		.aluSrc2(ALUSrc_o),
		.ALU_operation_i(ALUopcode),
		.result(ALU_res),
		.zero(ALUzero),
		.overflow(ALUoverflow)
	);

	Shifter shifter (
		.result(shifter_res),
		.leftRight(leftRight_o),
		.shamt(instr[10:6]),
		.sftSrc(ALUSrc_o)
	);

	Mux3to1 #(
		.size(32)
	) RDdata_Source (
		.data0_i (ALU_res),
		.data1_i (shifter_res),
		.data2_i (zeroData),
		.select_i(FURslt_sig),
		.data_o  (compute_res)
	);

	Data_Memory DM (
		.clk_i(clk_i),
		.addr_i(compute_res),
		.data_i(RTdata),
		.MemRead_i(MemRead_sig),
		.MemWrite_i(MemWrite_sig),
		.data_o(DMdata)
	);

	Mux2to1 #(
		.size(32)
	) Mux_Write (
		.data0_i(compute_res),
		.data1_i(DMdata),
		.select_i(MemtoReg_sig),
		.data_o(WriteRF_data)
	);

endmodule




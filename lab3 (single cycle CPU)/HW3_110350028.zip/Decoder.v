module Decoder (
	instr_op_i,
	RegWrite_o,
	ALUOp_o,
	ALUSrc_o,
	RegDst_o,
	Jump_o,
	Branch_o,
	BranchType_o,
	MemRead_o,
	MemWrite_o,
	MemtoReg_o
);

	//Parameter
	parameter OP_R_TYPE=	6'b000000;
	parameter OP_ADDI  =	6'b010011;
	parameter OP_BEQ   =	6'b011001;
	parameter OP_LUI   =	6'b001101;
	parameter OP_LW    =	6'b011000;
	parameter OP_SW    =	6'b101000;
	parameter OP_BNE   =	6'b011010;
	parameter OP_JUMP  =	6'b001100;
	parameter OP_JAL   =	6'b001111;
	parameter OP_BLT   =	6'b011100;
	parameter OP_BNEZ  =	6'b011101;
	parameter OP_BGEZ  =	6'b011110;
	
	parameter ALU_OP_NOP    = 3'b000;
	parameter ALU_OP_R_TYPE = 3'b001;
	parameter ALU_OP_ADDI   = 3'b010;
	parameter ALU_OP_LW_SW  = 3'b011;
	parameter ALU_OP_BEQ    = 3'b100;
	parameter ALU_OP_BNE    = 3'b101;
	parameter ALU_OP_BLT    = 3'b110;
	parameter ALU_OP_BGEZ   = 3'b111;

	// I/O ports
	input [6-1:0] instr_op_i;

	output RegWrite_o;
	output [3-1:0] ALUOp_o;
	output ALUSrc_o;
	output RegDst_o;
	output Jump_o;
	output Branch_o;
	output BranchType_o;
	output MemRead_o;
	output MemWrite_o;
	output MemtoReg_o;

	//Internal Signals
	reg RegWrite_o;
	reg [3-1:0] ALUOp_o;
	reg ALUSrc_o;
	reg RegDst_o;
	reg Jump_o;
	reg Branch_o;
	reg BranchType_o;
	reg MemRead_o;
	reg MemWrite_o;
	reg MemtoReg_o;

	//Main function
	always @(*) begin
		case (instr_op_i)
			 /*OP_LUI: begin
				RegWrite_o= 1;
				ALUOp_o= ALU_OP_NOP;
				ALUSrc_o= 1;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end*/
			OP_R_TYPE: begin
				RegWrite_o= 1;
				ALUOp_o= ALU_OP_R_TYPE;
				ALUSrc_o= 0;
				RegDst_o= 1;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_ADDI: begin
				RegWrite_o= 1;
				ALUOp_o= ALU_OP_ADDI;
				ALUSrc_o= 1;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_LW: begin
				RegWrite_o= 1;
				ALUOp_o= ALU_OP_LW_SW;
				ALUSrc_o= 1;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 1;
				MemWrite_o= 0;
				MemtoReg_o= 1;
			end
			OP_SW: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_LW_SW;
				ALUSrc_o= 1;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 1;
				MemtoReg_o= 0;
			end
			OP_JUMP: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_NOP;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 1;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_JAL: begin
				RegWrite_o= 1;
				ALUOp_o= ALU_OP_NOP;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 1;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_BEQ: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_BEQ;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 1;
				BranchType_o= 1;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_BNE: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_BNE;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 1;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_BLT: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_BLT;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 1;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_BNEZ: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_BNE;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 1;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			OP_BGEZ: begin
				RegWrite_o= 0;
				ALUOp_o= ALU_OP_BGEZ;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 1;
				BranchType_o= 1;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
			default: begin
				RegWrite_o= 0;
				ALUOp_o= 4'd0;
				ALUSrc_o= 0;
				RegDst_o= 0;
				Jump_o= 0;
				Branch_o= 0;
				BranchType_o= 0;
				MemRead_o= 0;
				MemWrite_o= 0;
				MemtoReg_o= 0;
			end
		endcase
	end
endmodule

module ALU_Ctrl (
	funct_i,
	ALUOp_i,
	ALU_operation_o,
	FURslt_o,
	leftRight_o,
	JRsrc_o
);

	// parameter
	// mux param
	parameter ALU  = 2'd0;
	parameter SHIFT= 2'd1;
	parameter ZERO = 2'd2;
	
	// ALU opcode
	parameter ADD = 4'b0010;
	parameter SUB = 4'b0110;
	parameter AND = 4'b0000;
	parameter OR  = 4'b0001;
	parameter NOR = 4'b1100;
	parameter LESS= 4'b0111;
	
	// funct_i param
	parameter FUNC_ADD = 6'b100011;
	parameter FUNC_SUB = 6'b010011;
	parameter FUNC_AND = 6'b011111;
	parameter FUNC_OR  = 6'b101111;
	parameter FUNC_NOR = 6'b010000;
	parameter FUNC_SLT = 6'b010100;
	parameter FUNC_SLLV= 6'b011000;
	parameter FUNC_SLL = 6'b010010;
	parameter FUNC_SRLV= 6'b101000;
	parameter FUNC_SRL = 6'b100010;
	parameter FUNC_JR  = 6'b000001;
	
	// ALUOp_i param
	parameter ALU_OP_NOP   = 3'b000;
	parameter ALU_OP_R_TYPE= 3'b001;
	parameter ALU_OP_ADDI  = 3'b010;
	parameter ALU_OP_LW_SW = 3'b011;
	parameter ALU_OP_BEQ   = 3'b100;
	parameter ALU_OP_BNE   = 3'b101;
	parameter ALU_OP_BLT   = 3'b110;
	parameter ALU_OP_BGEZ  = 3'b111;

	//I/O ports
	input [6-1:0] funct_i;
	input [3-1:0] ALUOp_i;

	output [4-1:0] ALU_operation_o;
	output [2-1:0] FURslt_o;
	output leftRight_o;
	output JRsrc_o;

	//Internal Signals
	reg [4-1:0] ALU_operation_o;
	reg [2-1:0] FURslt_o;
	reg leftRight_o;
	reg JRsrc_o;

	//Main function
	always @(ALUOp_i, funct_i) begin
		// Default values
		ALU_operation_o = 4'b0000;
		FURslt_o = 2'b00;
		leftRight_o = 1'b0;
		JRsrc_o = 1'b0;

		// ALU_operation_o
		case (ALUOp_i)
			ALU_OP_R_TYPE:
				case (funct_i)
					FUNC_ADD: ALU_operation_o= ADD;
					FUNC_SUB: ALU_operation_o= SUB;
					FUNC_AND: ALU_operation_o= AND;
					FUNC_OR:  ALU_operation_o= OR;
					FUNC_NOR: ALU_operation_o= NOR;
					FUNC_SLT: ALU_operation_o= LESS;
					default:  ALU_operation_o= 4'b0;
				endcase
			ALU_OP_ADDI, ALU_OP_LW_SW:	ALU_operation_o= ADD;
			ALU_OP_BEQ, ALU_OP_BNE:		ALU_operation_o= SUB;
			ALU_OP_BLT, ALU_OP_BGEZ:	ALU_operation_o= LESS;
			default: ALU_operation_o= 4'b0;
		endcase
		
		// FURslt_o
		case (ALUOp_i)
			ALU_OP_R_TYPE:
				case(funct_i)
					FUNC_ADD, FUNC_SUB, FUNC_AND, FUNC_OR, FUNC_NOR, FUNC_SLT: FURslt_o= ALU;
					FUNC_SRL, FUNC_SRLV, FUNC_SLL, FUNC_SLLV: FURslt_o= SHIFT;
					default: FURslt_o= 2'b10;
				endcase
			ALU_OP_ADDI, ALU_OP_LW_SW, ALU_OP_BEQ, ALU_OP_BNE, ALU_OP_BLT, ALU_OP_BGEZ: FURslt_o= ALU;
			default: FURslt_o= 2'b10;
		endcase
		
		// leftRight_o
		case (ALUOp_i)
			ALU_OP_R_TYPE:
				case(funct_i)
					FUNC_SLL, FUNC_SLLV: leftRight_o= 1'b1;
					FUNC_SRL, FUNC_SRLV: leftRight_o= 1'b0;
					default: leftRight_o= 1'b0;
				endcase
			default: leftRight_o= 1'b0;
		endcase
		
		// JRsrc_o
		case (ALUOp_i)
			ALU_OP_R_TYPE:
				case(funct_i)
					FUNC_JR: JRsrc_o= 1'b1;
					default: JRsrc_o= 1'b0;
				endcase
			default: JRsrc_o= 1'b0;
		endcase
	end
endmodule
